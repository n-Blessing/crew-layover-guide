/// <reference types="astro/client" />
/// <reference path="integrations/_sanity_astro/types.d.ts" />
/// <reference path="content.d.ts" />